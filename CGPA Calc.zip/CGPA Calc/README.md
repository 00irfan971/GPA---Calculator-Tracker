This is a GPA calculator I made for the National Institute of Technology,Jalandhar.  The project is made of Swift and SwiftUI for IOS. 

The App opens to a generic Calculator with a very user friendly UI which displays the course name, grade and credits of each course along with the GPA. 

There is also another page to help you track your GPA troughout the semesters in College. 
