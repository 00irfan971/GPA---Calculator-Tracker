//
//  CalcView.swift
//  CGPA Calc
//
//  Created by Irfan on 09/08/24.
//

import SwiftUI
import SwiftData
import GoogleMobileAds

struct userData:Identifiable{
    var id = UUID()
    var Course:String=""
    var Grade:String=""
    var credits:Int=1
    var CG:Double=0.00
    var Scale:String=""
    
}



struct CalcView: View {
    @State var cgpa:Float=0.00
    
    @State private var userdata=userData()
    
    @State private var showSheet:Bool = false
    
    @State private var showSheet2:Bool = false
    
    @State private var SCale:String=""
    
    @State private var CourseDataList: [userData]=[]
    
    @StateObject var interstitialAdsManager=InterstitialAdsManager()
    
    @State private var hasShownAd: Bool = false

    var body: some View{
        
        NavigationView{
            
            ZStack{
                Color.black.opacity(0.92).ignoresSafeArea()
                
                VStack{
                    HStack{
    
                        NavigationLink(destination: UniView(userdata: $userdata,SCale: $SCale, saveScale:saveScaleToLocalStorage)){
                            Image(systemName:"building.columns.fill").foregroundColor(.white).font(.system(size: 28,weight:.bold))
                        }
                        Button(action: {
                            if CourseDataList.count == 3 && !hasShownAd {interstitialAdsManager.displayInterstitialAd()
                                
                                hasShownAd=true
                            }
    
                            else {
                                showSheet.toggle()
                            }
                            }, label:{
                            Image(systemName: "plus").foregroundColor(.white).font(.system(size: 38,weight:.bold))
                        }).frame(width:310,alignment: .trailing).sheet(isPresented: $showSheet, content:{ DataSheetView(userdata: $userdata, onSave: addData,SCale: $SCale)})
                    }
                    
                    ZStack{
                        CircularProgressView(progress:Calc(),SCale: SCale).frame(width:250,height:250)
                        
                        VStack{
                            Text("CGPA").font(.system(size: 25,weight: .semibold,design: .rounded)).foregroundColor(.white)
                            
                            Text((CourseDataList.isEmpty ? "0.00" :String(Calc()))).foregroundColor(.white).font(.system(size: 70,weight: .bold))
                        }
                
                    }
                    
                    ScrollView{
                        ForEach(CourseDataList) { user in
                            
                            ZStack{
                                Rectangle().frame(width:350,height: 70).cornerRadius(7).foregroundColor(Color("MyGray"))
                                
                                HStack{
                                    Text("\(user.Grade)").foregroundColor(.white).frame(width:70,height: 75).background(Color.blue
                                        .opacity(0.75)).font(.system(size: 36)).cornerRadius(15).padding(.leading)
                                    
                                    VStack{
                                        Text("\(user.Course)").frame(width:200,alignment: .leading).foregroundColor(.white).font(.system(size: 30,weight: .medium))
                                        
                                        Text("Credits: \(user.credits)").frame(width:200,alignment: .leading).foregroundColor(.gray)
                                    }
                                    Spacer()
                                    
                                    Button(action: {deleteEntry(id: user.id)}, label: {
                                        Image(systemName: "trash").foregroundColor(.red)
                                    }).frame(height: 50,alignment: .top).padding(.trailing,30)
                                    
                                }
                            }
                        }
                    }.frame(height: 300)
                    
                    GeometryReader { geometry in
                        let adSize = GADCurrentOrientationAnchoredAdaptiveBannerAdSizeWithWidth(geometry.size.width)
                        GADBannerViewController(adSize)
                    }
                    Spacer()
                }
                
            }.onAppear {
                loadScaleFromLocalStorage()
                
                if !hasShownAd {
                                interstitialAdsManager.loadInterstitialAd()
                            }
                
            }
        }
            
    }
        
    func showInter(){
        interstitialAdsManager.displayInterstitialAd()
    }
        
    
    func deleteEntry(id: UUID) {
            if let index = CourseDataList.firstIndex(where: { $0.id == id }) {
            CourseDataList.remove(at: index)
            }
        }
    
    func addData(){
        
        CourseDataList.append(userdata)
        
        userdata=userData()
        
        
    }
    
    
    func Calc()->Double{
        var x:Double=0.00
        var z:Double=0.0
        var cg:Double=0.00
        
        
        
        var y: [String:Double] {
            switch SCale {
                
            case "1":
                return ["S":10.0, "A":9.0, "B":8.0, "C":7.0, "D":6.0, "E":5.0, "P":4.0]
                
            case "2":
                return ["S":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"E":5.0]
            case "3":
                return ["AA":10.0,"AB":9.0,"BB":8.0,"BC":7.0,"CC":6.0,"CD":5.0,"DD":4.0]
            case "4":
                return ["Ex":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"P":5.0]
            case "5":
                return ["A+":10.0,"A":9.0,"B+":8.0,"B":7.0,"C":6.0,"D":4.0]
            case "6":
                return ["A+":10.0,"A":9.0,"B":8.0,"C":6.0,"D":4.0]
                
            case "7":
                return ["O":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"E":5.0,"P":4.0]
            case "8":
                return ["A":10.0,"AB":9.0,"B":8.0,"BC":7.0,"C":6.0,"CD":5.0,"D":4.0]
            case "9":
                return ["A+":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"P":5.0]
            case "10":
                return ["AA":10.0,"AB":9.0,"BB":8.0,"BC":7.0,"CC":6.0,"CD":5.0,"D":4.0]
            case "11":
                return ["A+":10.0,"A":9.0,"B+":8.0,"B":7.0,"C+":6.0,"C":5.0]
            case "12":
                return ["Ex":10.0,"A":9.0,"B+":8.0,"B":7.0,"C":6.0]
            case "13":
                return ["S":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"P":5.0]
            case "14":
                return ["AA":10.0,"AB":9.0,"BB":8.0,"BC":7.0,"CC":6.0,"DD":4.0]
            case "15":
                return ["O":10.0,"A+":9.0,"A":8.0,"B+":7.0,"B":6.0,"C":5.0]
                
            case "16":
                return ["A":10.0,"A-":9.0,"B":8.0,"B-":7.0,"C":6.0,"C-":5.0,"D":4.0]
            case "17":
                return ["A":10.0,"A-":9.0,"B":8.0,"B-":7.0,"C":6.0,"C-":5.0,"D":4.0]
            case "18":
                return ["A+":10.0,"A":9.0,"B+":8.0,"B":7.0,"C+":6.0,"C":5.0,"D":4.0]
            case "19":
                return ["A":10.0,"A-":9.0,"B":8.0,"B-":7.0,"C":6.0,"C-":5.0]
            case "20":
                return ["O":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"E":4.0]
            case "21":
                return ["S":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"E":4.0]
            case "22":
                return ["O":10.0,"A+":9.0,"A":8.0,"B+":7.0,"B":6.0,"C":5.0,"D":4.0]
                
            case "23":
                return ["A+":10.0,"A":9.0,"A-":8.0,"B+":7.0,"B":6.0,"B-":5.0,"C+":4.0,"C":3.0]
            case "24":
                return ["A+":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"E":5.0]
            case "25":
                return ["O":10.0,"A+":9.0,"A":8.0,"B+":7.0,"B":6.0,"C":5.0,"P":4.0]
            case "26":
                return ["A+(4.3)":4.3,"A (4.0)":4.0,"B(3.0)":3.0,"C(2.0)":2.0,"D(1.0)":1.0]
            case "27":
                return ["A+(4.3)":4.3,"A(4.0)":4.0,"A-(3.7)":3.7,"B+(3.3)":3.3,"B(3.0)":3.0,"B-(2.7)":2.7,"C+(2.3)":2.3,"C(2.0)":2.0,"C-(1.7)":1.7,"D+(1.3)":1.3,"D(1.0)":1.0,"D-(0.7)":0.7]
            default:
                return ["S":10.0,"A":9.0,"B":8.0,"C":7.0,"D":6.0,"E":5.0]
            }
        }
        
    
            for course in CourseDataList{
                
                z=z+(Double(course.credits))
                
                
                x=x+(y[course.Grade] ?? 0.0)*Double(course.credits)
                
                cg=((x/z)*100).rounded()/100
                
                userdata.CG=cg
            }
            
        return cg;
    }
    
    func saveScaleToLocalStorage(_ scale: String) {
        UserDefaults.standard.set(scale, forKey: "savedScale")
        }
        
        // Load `SCale` from local storage using UserDefaults and JSON
    func loadScaleFromLocalStorage(){
        if let savedScale = UserDefaults.standard.string(forKey: "savedScale") {
                    SCale = savedScale
        }
    }
    
    struct CircularProgressView: View {
        var progress:Double=0.0
        var SCale:String
        
        var prog: Double {
            if SCale == "26" || SCale == "27" {
                return progress / 4
            } else {
                return progress / 10
            }
        }
        var body: some View {
            ZStack {
                Circle()
                    .stroke(
                        Color.green.opacity(0.35),
                        lineWidth: 30
                    )
                Circle()
                    .trim(from: 0, to: (prog)) // 1
                    .stroke(
                        Color.green,style:StrokeStyle(lineWidth: 30, lineCap: .round
                    ))
                    .rotationEffect(.degrees(-90)).animation(.easeInOut(duration: 2), value: (prog))
                
            }
        }
    }
    
}

#Preview {
    CalcView()
}


struct GADBannerViewController: UIViewControllerRepresentable {
    
    let adSize: GADAdSize

      init(_ adSize: GADAdSize) {
        self.adSize = adSize
      }
  
  func makeUIViewController(context: Context) -> some UIViewController {
    let view = GADBannerView(adSize: adSize)
    let viewController = UIViewController()
    let testID = "ca-app-pub-3940256099942544/2934735716"
    let realID = "ca-app-pub-6021683457131081/8744751727"
    
    // Banner Ad
    view.adUnitID = realID
    view.rootViewController = viewController
    
    // View Controller
    viewController.view.addSubview(view)
    viewController.view.frame = CGRect(origin: .zero, size: adSize.size)
    
    // Load an ad
    view.load(GADRequest())
    
    return viewController
  }
  
  func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {}
    
  
}

class AppDelegate2:NSObject,UIApplicationDelegate{
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        GADMobileAds.sharedInstance().start()
        return true
    }
}

