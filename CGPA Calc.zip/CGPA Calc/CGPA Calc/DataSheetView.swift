//
//  DataSheetView.swift
//  CGPA Calc
//
//  Created by Irfan on 03/08/24.
//

import SwiftUI

struct DataSheetView: View {
    @Binding var userdata:userData
    
    @State private var selectedIndex = 0
    
    @Environment(\.dismiss) private var dismiss
    
    let onSave: () -> Void
    
    let numbers = [1, 2, 3, 4, 5,6]
    
    

    var grades: [String] {
        switch SCale {
            
        case "1":
            return ["S", "A", "B", "C", "D", "E", "P"]
            
        case "2":
            return ["S","A","B","C","D","E"]
        case "3":
            return ["AA","AB","BB","BC","CC","CD","DD"]
        case "4":
            return ["Ex","A","B","C","D","P"]
        case "5":
            return ["A+","A","B+","B","C","D"]
        case "6":
            return ["A+","A","B","C","D"]
        case "7":
            return ["O","A","B","C","D","E","P"]
        case "8":
            return ["A","AB","B","BC","C","CD","D"]
        case "9":
            return ["A+","A","B","C","D","P"]
        case "10":
            return ["AA","AB","BB","BC","CC","CD","D"]
        case "11":
            return ["A+","A","B+","B","C+","C"]
        case "12":
            return ["Ex","A","B+","B","C"]
        case "13":
            return ["S","A","B","C","D","P"]
        case "14":
            return ["AA","AB","BB","BC","CC","DD"]
        case "15":
            return ["O","A+","A","B+","B","C"]
        case "16":
            return ["A","A-","B","B-","C","C-","D"]
        case "17":
            return ["A","A-","B","B-","C","C-","D"]
        case "18":
            return ["A+","A","B+","B","C+","C","D"]
        case "19":
            return ["A","A-","B","B-","C","C-"]
        case "20":
            return ["O","A","B","C","D","E"]
        case "21":
            return ["S","A","B","C","D","E"]
        case "22":
            return ["O","A+","A","B+","B","C","D"]
        case "23":
            return ["A+","A","A-","B+","B","B-","C+","C"]
        case "24":
            return ["A+","A","B","C","D","E"]
        case "25":
            return ["O","A+","A","B+","B","C","P"]
        case "26":
            return ["A+(4.3)","A","B","C","D"]
        case "27":
            return ["A+(4.3)","A(4.0)","A-(3.7)","B+(3.3)","B(3.0)","B-(2.7)","C+(2.3)","C(2.0)","C-(1.7)","D+(1.3)","D(1.0)","D-(0.7)"]
            
        default:
            return ["S", "A", "B", "C", "D", "E"]
        }
    }
    
    @Binding var SCale:String
    //let grades = ["S","A","B","C","D","E"]
    
    var body: some View {
        ZStack{
            Color.black.opacity(0.92).ignoresSafeArea()
            
            VStack{
                
                Text("Add Course").foregroundColor(.white).font(.system(size: 45,weight: .bold)).frame(width: 350,alignment: .leading)
                
                Section(header: Text("Course Name").frame(width:350,height:25,alignment: .leading).font(.system(size: 16)).foregroundColor(.gray))
                {
                    TextField("Name", text: $userdata.Course).autocorrectionDisabled().frame(width: 350,height: 30).background(Color("MyGray")).cornerRadius(5).foregroundColor(.white).padding(.bottom)
                    
                }
                
                
                    
                    Section(header: Text("Credit Hours").frame(width:350,alignment: .leading).font(.system(size: 16)).foregroundColor(.gray)){
                        
                        Picker("",selection: $userdata.credits){
                            ForEach(numbers,id:\.self){
                                number in Text(String(number)).foregroundColor(.white)
                            }
                        }.pickerStyle(WheelPickerStyle()).frame(width: 350,height: 160).background(Color.black.opacity(0.35)).cornerRadius(7.0)
                    }
                    
                    
                    
                    Section(header: Text("Grade").frame(width:350,alignment: .leading).font(.system(size: 16)).foregroundColor(.gray)){
                        
                        Picker("",selection: $userdata.Grade){
                            ForEach(grades,id:\.self){
                                number in Text(String(number)).foregroundColor(.white)
                            }
                        }.pickerStyle(WheelPickerStyle()).frame(width: 350,height: 160).background(Color.black.opacity(0.35)).cornerRadius(7.0).onAppear{
                            if userdata.Grade.isEmpty{
                                userdata.Grade=grades.first ?? ""
                            }
                        }
                        
                        
                    }
                
                Button(action: {
                    onSave()
                    dismiss()
                }, label: {
                    Text("DONE").frame(width:350,height: 40).background(Color("MyGray")).foregroundColor(.white).cornerRadius(7).padding()
                })
                
                
                
                    
                    
                    
                }
            }
        }
    }


#Preview {
    DataSheetView(userdata: .constant(userData()),onSave: {},SCale: .constant("1"))
}
