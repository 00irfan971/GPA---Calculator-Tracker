//
//  UniView.swift
//  CGPA Calc
//
//  Created by Irfan on 20/09/24.
//

import SwiftUI

struct UniView: View {
    
    let UniList = [["uni": "American Scale (4.0)", "Image": "US","scale":"27"],["uni": "NIT Warangal", "Image": "NIT_Warangal","scale":"1"],
                   ["uni": "NIT Trichy", "Image": "NIT_Trichy","scale":"2"],
                   ["uni": "NIT Surathkal", "Image": "NIT_Surathkal","scale":"3"],
                   ["uni": "NIT Rourkela", "Image": "NIT_Rourkela","scale":"4"],
                   ["uni": "NIT Calicut", "Image": "NIT_Calicut","scale":"2"],
                   ["uni": "NIT Allahabad", "Image": "NIT_Allahabad","scale":"5"],
                   ["uni": "NIT Kurukshetra", "Image": "NIT_Kkr","scale":"6"],
                   ["uni": "NIT Durgapur", "Image": "NIT_Dgp","scale":"4"],
                   ["uni": "NIT Jalandhar", "Image": "NIT_Jalandhar","scale":"2"],
                   ["uni": "NIT Jamshedpur", "Image": "NIT_Jamshedpur","scale":"7"],
                   ["uni": "NIT Hamirpur", "Image": "NIT_Hamirpur","scale":"8"],
                   ["uni": "NIT Nagpur (VNIT)", "Image": "NIT_Nagpur"],
                   ["uni": "NIT Silchar", "Image": "NIT_Silchar","scale":"3"],
                   ["uni": "NIT Patna", "Image": "NIT_Patna","scale":"9"],
                   ["uni": "NIT Jaipur (MNIT)", "Image": "NIT_Jaipur","scale":"10"],
                   ["uni": "NIT Agartala", "Image": "NIT_Agartala","scale":"4"],
                   ["uni": "NIT Srinagar", "Image": "NIT_Srinagar","scale":"11"],
                   ["uni": "NIT Raipur", "Image": "NIT_Raipur","scale":"11"],
                   ["uni": "NIT Meghalaya", "Image": "NIT_Meghalaya","scale":"3"],
                   ["uni": "NIT Manipur", "Image": "NIT_Manipur","scale":"4"],
                   ["uni": "NIT Arunachal Pradesh", "Image": "NIT_AP","scale":"12"],
                   ["uni": "NIT Goa", "Image": "NIT_Goa","scale":"13"],
                   ["uni": "NIT Puducherry", "Image": "NIT_Puducherry","scale":"2"],
                   ["uni": "NIT Sikkim", "Image": "NIT_Sikkim","scale":"2"],
                   ["uni": "NIT Uttarakhand", "Image": "NIT_Uttarakhand","scale":"14"],
                   ["uni": "NIT Mizoram", "Image": "NIT_Mizoram","scale":"15"],
                   ["uni": "SRM University", "Image": "SRM","scale":"15"],
                   
                   ["uni": "VIT", "Image": "VIT","scale":"1"],
                   
                   ["uni": "Thapar", "Image": "TIT","scale":"19"],
                   ["uni": "LPU", "Image": "LPU","scale":"22"],
                   ["uni": "Amity University", "Image": "Amity","scale":"23"],
                   ["uni": "BITS", "Image": "BITS","scale":"16"],
                   ["uni": "Manipal", "Image": "MIT","scale":"24"],
                   ["uni": "Chandigarh University", "Image": "CU","scale":"18"],
                   ["uni": "MIT - WPU", "Image": "MITWPU","scale":"25"],
                   ["uni": "Punjab Engineering College", "Image": "PEC","scale":"18"],
                   
                   
                   ["uni": "IIT Kharagpur", "Image": "IIT_Kharagpur", "scale": "4"],
                       ["uni": "IIT Bombay", "Image": "IIT_Bombay", "scale": "3"],
                       ["uni": "IIT Madras", "Image": "IIT_Madras", "scale": "2"],
                       ["uni": "IIT Kanpur", "Image": "IIT_Kanpur", "scale": "16"],
                       ["uni": "IIT Delhi", "Image": "IIT_Delhi", "scale": "17"],
                       ["uni": "IIT Guwahati", "Image": "IIT_Guwahati", "scale": "3"],
                       ["uni": "IIT Roorkee", "Image": "IIT_Roorkee", "scale": "18"],
                       ["uni": "IIT Bhubaneswar", "Image": "IIT_Bhubaneswar", "scale": "4"],
                       ["uni": "IIT Gandhinagar", "Image": "IIT_Gandhinagar"],
                       ["uni": "IIT Hyderabad", "Image": "IIT_Hyderabad", "scale": "19"],
                       ["uni": "IIT Jodhpur", "Image": "IIT_Jodhpur", "scale": "17"],
                       ["uni": "IIT Patna", "Image": "IIT_Patna", "scale": "3"],
                       ["uni": "IIT Indore", "Image": "IIT_Indore", "scale": "3"],
                       ["uni": "IIT Ropar", "Image": "IIT_Ropar", "scale": "17"],
                       ["uni": "IIT Mandi", "Image": "IIT_Mandi", "scale": "20"],
                       ["uni": "IIT BHU", "Image": "IIT_BHU", "scale": "2"],
                       ["uni": "IIT Tirupati", "Image": "IIT_Tirupati", "scale": "21"],
                       ["uni": "IIT Palakkad", "Image": "IIT_Palakkad", "scale": "21"],
                       ["uni": "IIT Dhanbad (ISM)", "Image": "IIT_Dhanbad", "scale": "18"],
                       ["uni": "IIT Goa", "Image": "IIT_Goa", "scale": "18"],
                       ["uni": "IIT Jammu", "Image": "IIT_Jammu", "scale": "3"],
                       ["uni": "IIT Bhilai", "Image": "IIT_Bhilai", "scale": "17"],
                       ["uni": "IIT Dharwad", "Image": "IIT_Dharwad", "scale": "3"]]
    
    @State var searchTerm = ""
    
    @State var clickedItem:String?=nil
    
    @Environment(\.presentationMode) var presentationMode
    
    var FilteredUniList: [[String:String]]{
        if searchTerm.isEmpty{
            return UniList
        }else{
            return UniList.filter{
                $0["uni"]?.localizedCaseInsensitiveContains(searchTerm) ?? false
            }
        }
    }
    
    
    
    @Binding var userdata:userData
    
    
    @Binding var SCale:String
    
    var saveScale:(String)->Void
  
    var body: some View {
        
        ZStack{
            
            Color.black.opacity(0.92).ignoresSafeArea()
            
            VStack{
                NavigationStack{
                    
                    List(FilteredUniList, id: \.self){ Uni in
                        
                        if let name = Uni["uni"],let photo=Uni["Image"],let scale=Uni["scale"]{
                            
                            Button(action: {
                                SCale=scale
                                saveScale(scale)
                                
                                
                                withAnimation(.easeInOut(duration: 0.2)){
                                    clickedItem=name
                                }
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                                    clickedItem = nil
                                    
                                    presentationMode.wrappedValue.dismiss()
                                }
                            }){
                                HStack{
                                    Image(photo).resizable().frame(width:40,height:40).clipShape(Circle())
                                    
                                    Text(name).font(.system(size: 20,weight: .medium)).foregroundColor(.white)
                                }.opacity(clickedItem == name ? 0.2 : 1.0)
                                
                            }.listRowBackground(Color.black.opacity(0.5))
                            
                        }
                        
                    }.scrollContentBackground(.hidden).background(Color.black.opacity(0.92))
                }.searchable(text: $searchTerm,prompt: "Search University/System").autocorrectionDisabled()
                
            }
            
        }
        

       
}
}

#Preview {
    UniView(userdata: .constant(userData()), SCale: .constant(""),saveScale: { scale in
        print("Scale saved: \(scale)")
    })
}
