//
//  GuideView.swift
//  CGPA Calc
//
//  Created by Irfan on 18/10/24.
//

import SwiftUI

struct GuideView: View {
    @Binding var hasSeenGuide: Bool
    var body: some View {
        
        ZStack{
            Color.black.opacity(0.92).ignoresSafeArea()
            
            VStack{
                
                HStack{
                    Image(systemName:"building.columns.fill").foregroundColor(.white).font(.system(size: 28,weight:.bold))
                    
                    Spacer()
                    
                    Image(systemName: "plus").foregroundColor(.white).font(.system(size: 38,weight:.bold))
                }.frame(width:360,alignment: .trailing)
                
                ZStack{
                    CircularProgressViewS(progress:0.0,SCale: "0").frame(width:250,height:250)
                    
                    VStack{
                        Text("CGPA").font(.system(size: 25,weight: .semibold,design: .rounded)).foregroundColor(.white)
                        
                        Text( "0.00").foregroundColor(.white).font(.system(size: 70,weight: .bold))
                    }
            }
            
                    
                    Spacer()
    }
            
            VStack{
                HStack{
                    Image("g1").resizable().frame(width:240,height:160).padding(.top,34).padding(.leading,15)
                    Spacer()
                }
                Spacer()
                
            }
            Button(action: {
                hasSeenGuide=true
            }, label: {
                Text("").frame(maxWidth: .infinity,maxHeight: .infinity)
            })
        }
        
        
    }
    struct CircularProgressViewS: View {
        var progress:Double=0.0
        var SCale:String
        
        var prog: Double {
            if SCale == "26" || SCale == "27" {
                return progress / 4
            } else {
                return progress / 10
            }
        }
        var body: some View {
            ZStack {
                Circle()
                    .stroke(
                        Color.green.opacity(0.35),
                        lineWidth: 30
                    )
                Circle()
                    .trim(from: 0, to: (prog)) // 1
                    .stroke(
                        Color.green,style:StrokeStyle(lineWidth: 30, lineCap: .round
                                                     ))
                    .rotationEffect(.degrees(-90)).animation(.easeInOut(duration: 2), value: (prog))
                
            }
        }
    }
    
}

#Preview {
    GuideView(hasSeenGuide: .constant(false))
}
