//
//  AddSemView.swift
//  CGPA Calc
//
//  Created by Irfan on 10/08/24.
//
import SwiftUI
import UIKit

// Custom UITextField with Done button added to the decimalPad
struct CustomDecimalTextField: UIViewRepresentable {
    @Binding var text: String
    
    class Coordinator: NSObject, UITextFieldDelegate {
        var parent: CustomDecimalTextField

        init(parent: CustomDecimalTextField) {
            self.parent = parent
        }

        // Dismiss the keyboard when "Done" is tapped
        @objc func doneButtonTapped() {
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        }

        func textFieldDidChangeSelection(_ textField: UITextField) {
            parent.text = textField.text ?? ""
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> UITextField {
        let textField = UITextField()
        textField.keyboardType = .decimalPad
        textField.delegate = context.coordinator
        textField.borderStyle = .none
        textField.placeholder = "SGPA" // Set placeholder text
        
        // Set the background color to "MyGray" for the UITextField input area
        textField.backgroundColor = UIColor(named: "MyGray")
        textField.textColor = .white // Set text color to white

        // Create a toolbar with a Done button and attach it to the UITextField
        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: context.coordinator, action: #selector(context.coordinator.doneButtonTapped))
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([flexSpace, doneButton], animated: false)

        textField.inputAccessoryView = toolbar

        return textField
    }

    func updateUIView(_ uiView: UITextField, context: Context) {
        uiView.text = text
    }
}

// Your AddSemView with UIKit-based Decimal TextField
struct AddSemView: View {
    @Binding var Sem: sem
    @Environment(\.dismiss) private var dismiss
    
    var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    var cred = (1...40)
    
    let onSave: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.92).ignoresSafeArea() // Background black
            
            VStack {
                Text("Add Semester")
                    .foregroundColor(.white)
                    .font(.system(size: 45, weight: .bold))
                    .frame(width: 350, alignment: .leading)
                    .padding()
                
                Section(header: Text("Semester Number")
                    .frame(width: 350, alignment: .leading)
                    .font(.system(size: 16))
                    .foregroundColor(.gray)) {
                    Picker("", selection: $Sem.name) {
                        ForEach(numbers, id: \.self) { number in
                            Text(String(number)).foregroundColor(.white)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(width: 350, height: 160)
                    .background(Color.black.opacity(0.35))
                    .cornerRadius(7.0)
                }
                .padding(.bottom)
                
                Section(header: Text("Enter SGPA")
                    .frame(width: 350, alignment: .leading)
                    .font(.system(size: 16))
                    .foregroundColor(.gray)) {
                        
                    CustomDecimalTextField(text: $Sem.SCG) // UIKit-based Decimal TextField with Done button
                        .frame(width: 350, height: 35) // Set width and height
                        .padding(.horizontal)
                        .background(Color("MyGray")) // "MyGray" color for input field
                        .cornerRadius(5)
                        .foregroundColor(.white)
                        .padding(.bottom)
                }
                
                Section(header: Text("Total Credits")
                    .frame(width: 350, alignment: .leading)
                    .font(.system(size: 16))
                    .foregroundColor(.gray)) {
                    Picker("", selection: $Sem.credits) {
                        ForEach(cred, id: \.self) { cred in
                            Text(String(cred)).foregroundColor(.white)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(width: 350, height: 160)
                    .background(Color.black.opacity(0.35))
                    .cornerRadius(7.0)
                }
                .padding(.bottom)
                
                Button(action: {
                    onSave()
                    dismiss()
                }) {
                    Text("DONE")
                        .frame(width: 350, height: 50)
                        .bold()
                        .background(Color("MyGray"))
                        .foregroundColor(.white)
                        .cornerRadius(7)
                        .padding()
                }
            }
        }
    }
}

#Preview {
    AddSemView(Sem: .constant(sem()), onSave: {})
}
