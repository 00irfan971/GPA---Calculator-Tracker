//
//  ContentView.swift
//  CGPA Calc
//
//  Created by Irfan on 03/08/24.
//

import SwiftUI
import SwiftData
import GoogleMobileAds


struct ContentView: View {
    
    @AppStorage("hasSeenGuide") private var hasSeenGuide: Bool = false
    
    init() {
        
            UITabBar.appearance().unselectedItemTintColor = UIColor.white
        
        
        }
    var body: some View{
        
        if hasSeenGuide {
            TabView{
                
                CalcView().tabItem { Label("Calculate", systemImage: "plus.rectangle") }
                
                HomeView().tabItem { Label("My Tracker", systemImage: "record.circle")
                }
            }
                } else {
                    GuideView(hasSeenGuide: $hasSeenGuide)
                }
        
        
        
    }
    
}

#Preview {
    ContentView()
}


