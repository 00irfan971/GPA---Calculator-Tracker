//
//  CGPA_CalcApp.swift
//  CGPA Calc
//
//  Created by Irfan on 03/08/24.
//

import SwiftUI
import SwiftData

import GoogleMobileAds

class AppDelegate: UIResponder, UIApplicationDelegate {

  func application(_ application: UIApplication,
      didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

    GADMobileAds.sharedInstance().start(completionHandler: nil)

    return true
  }
}




@main
struct CGPA_CalcApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            NavigationView{
                ContentView()
                
            }
        }
    }
}
